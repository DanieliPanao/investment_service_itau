﻿using System;
namespace Calculadora
{
    public class Operacoes
    {
        public long valorA {get;set;}
        public char operador {get;set;}
        public long valorB {get;set;}
        public long resultado {get;set;}
    }
}
